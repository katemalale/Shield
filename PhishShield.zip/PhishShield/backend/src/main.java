import models.PhishDetector;
import utils.FeatureExtractor;

public class Main {
    public static void main(String[] args) {
        PhishDetector detector = new PhishDetector();
        FeatureExtractor extractor = new FeatureExtractor();
        // Load and prepare your data here
        detector.trainModel(); // Train the model on your dataset
        // Sample prediction
        String url = "http://example.com/phishing";
        System.out.println("Is phishing: " + detector.predict(url));
    }
}
