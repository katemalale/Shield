const express = require('express');
const router = express.Router();

router.post('/', (req, res) => {
    const { url } = req.body;
    // Call Java model prediction here via shell or HTTP request
    res.send({ isPhishing: false });
});

module.exports = router;
